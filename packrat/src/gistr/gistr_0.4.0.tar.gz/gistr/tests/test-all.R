library('testthat')
library('gistr')

test_check("gistr")
