.onLoad <- function(libname, pkgname){
  options(bokeh_theme = bk_default_theme())
}
